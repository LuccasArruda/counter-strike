public class FogaoExercicio {
    public static void main(String[] args) {
        Fogao fogao = new Fogao("Dako");
        fogao.exibirDadosFogao();
    }
}
